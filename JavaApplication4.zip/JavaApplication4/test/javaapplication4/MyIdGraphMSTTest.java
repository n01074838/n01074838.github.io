/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Pramit Roy (n01074838)
 */
public class MyIdGraphMSTTest {
    
    public MyIdGraphMSTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class MyIdGraphMST.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MyIdGraphMST.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
        String[] vertices = {"0", "1", "3", "4", "7", "8"};
        
        int[][] edges = new int[][]{
        {0, 1, 2}, {0, 4, 3}, {0, 5, 15},
        {1, 0, 2},
        {2, 4, 1}, {2, 5, 6},
        {3, 4, 5},
        {4, 0, 3}, {4, 2, 1}, {4, 5, 12},
        {5, 0, 15}, {5, 2, 6}, {5, 3, 5}, {5, 4, 12}
        };

        WeightedGraph<String> graph2 = new WeightedGraph<>(vertices, edges);
        WeightedGraph<String>.MST tree2 =
        graph2.getMinimumSpanningTree();
        double res = 11.0;
        assertEquals(res, tree2.getTotalWeight(), 0);
    }
    
}
