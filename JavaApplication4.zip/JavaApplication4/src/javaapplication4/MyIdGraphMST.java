/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author Pramit Roy (n01074838)
 */
import java.util.*;
public class MyIdGraphMST {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        String[] vertices = {"0", "1", "3", "4", "7", "8"};
        
        int[][] edges = new int[][]{
        {0, 1, 2}, {0, 4, 3}, {0, 5, 9},
        {1, 0, 2},
        {2, 4, 10}, {2, 5, 6},
        {3, 5, 5},
        {4, 0, 3}, {4, 2, 10}, {4, 5, 12},
        {5, 0, 9}, {5, 2, 6}, {5, 3, 5}, {5, 4, 12}
        };

        WeightedGraph<String> graph2 = new WeightedGraph<>(vertices, edges);
        WeightedGraph<String>.MST tree2 =
        graph2.getMinimumSpanningTree();
        System.out.println("\nTotal weight in MST is " + tree2.getTotalWeight());
        tree2.printTree();
    }
    
}
