/*
Team Members: Denis Stepanov, Kevin Libdan, Pramit Roy
Team name: Skynet
*/

package com.example.softwarecontrolleddrone;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void changeToMenuActivity(View view)
    {
        final EditText editText1 = (EditText) findViewById(R.id.usernameField);
        final EditText editText2 = (EditText) findViewById(R.id.passwordField);

        boolean usernameTest = checkUsername(editText1.getText().toString());//Username check
        if(usernameTest == false)//Username error msg
        {
            final Toast InvUname = Toast.makeText(LoginActivity.this, R.string.errorName, Toast.LENGTH_SHORT);//invalid username toast for 1 sec
                    InvUname.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    InvUname.cancel();
                }
            }, 1000);//set duration 1 sec = 1000mSec
        }

        boolean passwordTest = checkPassword(editText2.getText().toString());//password check
        if(passwordTest == false)//pass error msg
        {
            final Toast InvPass = Toast.makeText(LoginActivity.this, R.string.errorPassword, Toast.LENGTH_SHORT);//invalid password toast for 1 sec
                    InvPass.show();
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    InvPass.cancel();
                }
            }, 1000);//set duration 1 sec = 1000 mSec
        }

        Intent intent = new Intent(LoginActivity.this, MenuActivity.class);//login if Username and pass validated

        if((usernameTest == true && passwordTest == true)) {

            startActivity(intent);
        }
    }



    public boolean checkUsername(String name) {//Username validation
        if (!name.equals(getString(R.string.usernameField1)))
            return false;
        else
            return true;
    }

    public boolean checkPassword(String password) {//password validation
        if (password.equals(getString(R.string.passwordField1)))
            return true;
        else
            return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;
        switch (item.getItemId()) {
            case R.id.help://redirection for help option
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.ca/"));
                startActivity(intent);
                break;

            case R.id.scd://rediredtion for preject scd option
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.litehawk.ca/highroller/"));
                startActivity(intent);
                break;

            case R.id.drone://redirection for drone info potion(drone pic)
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dronestoronto.com/"));
                startActivity(intent);
                break;

        }

        return super.onOptionsItemSelected(item);
    }
}
