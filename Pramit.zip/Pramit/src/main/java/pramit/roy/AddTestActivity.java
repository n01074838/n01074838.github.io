package pramit.roy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AddTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_test);
    }
}
